<?php
/**
 * Environment config loader
 *
 * • Local development: add config/config.local.php (copy from config.local.example.php)
 * • Production (Hostinger, etc.): do NOT upload config.local.php — only config.production.php
 *
 * Rule: if config.local.php exists → it wins (local). If you delete it on the server,
 * PHP loads config.production.php instead.
 *
 * Constant VIVEK_CONFIG_SOURCE is set to 'local' or 'production' for debugging.
 * Empty DB_PASS with production file → clear error (avoids cryptic MySQL "using password: NO").
 */

$configDir = __DIR__;
/** @var string|null Which env file was loaded: 'local' | 'production' */
$vivekConfigSource = null;

if (is_file($configDir . '/config.local.php')) {
    require_once $configDir . '/config.local.php';
    $vivekConfigSource = 'local';
} elseif (is_file($configDir . '/config.production.php')) {
    require_once $configDir . '/config.production.php';
    $vivekConfigSource = 'production';
} else {
    // If we're installing, allow proceeding without config (installer will create it)
    $isInstaller = (strpos($_SERVER['SCRIPT_NAME'] ?? '', 'install.php') !== false) || 
                   (strpos($_SERVER['SCRIPT_NAME'] ?? '', 'run_migration.php') !== false);

    if (!$isInstaller && PHP_SAPI !== 'cli') {
        header("Location: /install.php");
        exit;
    }
    $vivekConfigSource = 'setup';
    if (!defined('APP_URL')) define('APP_URL', 'http://' . ($_SERVER['HTTP_HOST'] ?? 'localhost'));
    if (!defined('VIVEK_DEBUG')) define('VIVEK_DEBUG', true);
}

if ($vivekConfigSource !== 'setup') {
    $required = ['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASS', 'DB_CHARSET', 'APP_URL'];
    foreach ($required as $name) {
        if (!defined($name)) {
            die('Config error: ' . $name . ' must be defined in config.local.php or config.production.php');
        }
    }
}
if (!defined('DB_PORT')) {
    define('DB_PORT', 3306);
}
if (!defined('VIVEK_DEBUG')) {
    define('VIVEK_DEBUG', false);
}

define('VIVEK_CONFIG_SOURCE', $vivekConfigSource ?? 'unknown');
unset($vivekConfigSource);

// Production: empty DB_PASS → MySQL reports "(using password: NO)" — fail with a clear message
if (VIVEK_CONFIG_SOURCE === 'production' && DB_PASS === '') {
    if (PHP_SAPI !== 'cli') {
        header('Content-Type: text/plain; charset=utf-8', true, 503);
    }
    die(
        "Vivek CMS: DB_PASS is empty in config/config.production.php.\n\n"
        . "Hostinger / cPanel MySQL users always have a password — paste it from hPanel → Databases.\n"
        . "Also check you did NOT upload config.local.php (it overrides production).\n"
    );
}

// ============================================
// Shared (same for every environment)
// ============================================
define('APP_VERSION', '1.0.0');

define('BASE_PATH', dirname(__DIR__));
define('UPLOAD_PATH', BASE_PATH . '/assets/uploads/');
define('UPLOAD_URL', APP_URL . '/assets/uploads/');
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5MB

define('SESSION_NAME', 'vivek_cms_session');
define('HASH_COST', 12);
define('POSTS_PER_PAGE', 9);

date_default_timezone_set('Asia/Kolkata');

error_reporting(E_ALL);
ini_set('display_errors', VIVEK_DEBUG ? '1' : '0');
