<?php
/**
 * Database Connection (PDO)
 * Uses prepared statements to prevent SQL injection
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/mysql_dsn.php';

class Database {
    private static $instance = null;
    private $pdo;

    private function __construct() {
        try {
            $dsn = vivek_mysql_dsn(true);
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE  => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES    => false,
            ];
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            error_log("DB Connection Error: " . $e->getMessage());

            $isLocal = false;
            if (defined('APP_URL')) {
                $u = APP_URL;
                $isLocal = (strpos($u, 'localhost') !== false || strpos($u, '127.0.0.1') !== false);
            }
            $showDetail = $isLocal && (int) ini_get('display_errors') === 1;

            if ($isLocal) {
                $root = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 1);
                $sqlPath = $root . '/database/local-dev-grant.sql';
                $msg = '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Database setup</title></head><body style="font-family:system-ui,sans-serif;max-width:42rem;margin:2rem;line-height:1.5">';
                $msg .= '<h1>Database connection failed</h1>';
                $msg .= '<p>MySQL rejected the login or the database is missing. On a Mac with Homebrew MariaDB/MySQL, do this once:</p>';
                $msg .= '<ol>';
                $msg .= '<li>In Terminal, from your project folder:<br><code style="background:#f4f4f4;padding:.2rem .4rem">sudo mysql &lt; database/local-dev-grant.sql</code></li>';
                $msg .= '<li>Set <code>DB_PASS</code> in <code>config/config.local.php</code> to match <code>database/local-dev-grant.sql</code> (default: <code>change_me_local</code>).</li>';
                $msg .= '<li>Open <a href="/install.php">/install.php</a> once to create tables, then delete that file.</li>';
                $msg .= '</ol>';
                $msg .= '<p>Production uses <code>config/config.production.php</code> when <code>config.local.php</code> is absent.</p>';
                if ($showDetail) {
                    $msg .= '<p style="color:#666;font-size:.9rem"><strong>PDO:</strong> ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</p>';
                }
                $msg .= '</body></html>';
                die($msg);
            }

            die('❌ Database connection error. Please try again later.');
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->pdo;
    }

    // Prevent cloning
    private function __clone() {}
}

/**
 * Helper function to get DB connection
 */
function db() {
    return Database::getInstance()->getConnection();
}
