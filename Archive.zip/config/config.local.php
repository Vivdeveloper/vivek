<?php
/**
 * Your machine — gitignored. Copy from config.local.example.php if missing.
 */
define('DB_HOST', '127.0.0.1');
define('DB_PORT', 3306);
define('DB_NAME', 'vivek_cms');
define('DB_USER', 'vivchoudhary');
define('DB_PASS', 'change_me_local');
define('DB_CHARSET', 'utf8mb4');

define('APP_URL', 'http://127.0.0.1:9000');
define('VIVEK_DEBUG', true);
